import os

FILE_PATH = "./Hotel_H/hotel.txt"

# 1~3 층, 1~3 호 (총 9개의 방)
rooms = [[0 for _ in range(3)] for _ in range(3)]

def load_rooms():
    # 파일에서 방 현황 불러오기
    global rooms
    if os.path.exists(FILE_PATH):
        with open(FILE_PATH, "r", encoding="utf-8") as f:
            lines = f.readlines()
            for i in range(3):
                row = []
                for val in lines[i].strip().split():
                    if val == "---":   # 빈 방
                        row.append(0)
                    else:
                        row.append(val)  # 고객 이름 저장
                rooms[i] = row
    else:
        save_rooms()

def save_rooms():
    # 방 현황 파일에 저장
    with open(FILE_PATH, "w", encoding="utf-8") as f:
        for i in range(3):
            row = []
            for val in rooms[i]:
                if val == 0:
                    row.append("---")
                else:
                    row.append(str(val))
            f.write(" ".join(row) + "\n")

def show_rooms():
    print("\n현재 객실 현황 (빈방=---, 사용중=고객이름)\n")
    for floor in range(3, 0, -1):   # 3층부터 출력
        room_nums = []   # 객실번호 줄
        status = []      # 상태 줄
        for room in range(1, 4):
            room_nums.append(f"{floor}0{room}")
            val = rooms[floor-1][room-1]
            if val == 0:
                status.append("---") # 입력값 0, 빈 방일 때 --- 로 출력하게.
            else:
                status.append(str(val))
        print(" ".join(room_nums))
        print(" ".join(status))
    print()

def check_valid(floor, room):
    # 유효한 방 번호인지 확인
    return 1 <= floor <= 3 and 1 <= room <= 3

def main():
    load_rooms()

    while True:
        try:
            first = int(input("1.조회  2.입실  3.퇴실  4.종료 → "))
        except Exception:
            print("숫자를 입력해주십시오\n")
            continue

        if first == 1:  # 조회
            show_rooms()

        elif first == 2:  # 입실
            try:
                floor = int(input("몇 층에 입실하시겠습니까? (1~3): "))
                room = int(input("몇 호실에 입실하시겠습니까? (1~3): "))
            except Exception:
                print("숫자를 입력해주십시오.\n")
                continue

            if not check_valid(floor, room):
                print("존재하지 않는 방입니다.\n")
                continue

            if rooms[floor-1][room-1] == 0:
                while True:
                    name = input("입실하실 고객님 이름을 적어주세요. (3글자로):").strip()
                    if len(name) == 3: # 이름을 3글자로 적으라고 제한 검
                        rooms[floor-1][room-1] = name
                        save_rooms()
                        print(f"{floor}층 {room}호 [{name}] 입실 완료!\n")
                        break
                    else:
                        print("이름은 반드시 3글자로 입력해야 합니다.")                
            else:
                print("이미 사용 중인 방입니다. 죄송합니다.\n")

        elif first == 3:  # 퇴실
            try:
                floor = int(input("몇 층에서 퇴실하시겠습니까? (1~3): "))
                room = int(input("몇 호실에서 퇴실하시겠습니까? (1~3): "))
            except Exception:
                print("숫자를 입력해주십시오.\n")
                continue

            if not check_valid(floor, room):
                print("존재하지 않는 방입니다.\n")
                continue

            if rooms[floor-1][room-1] != 0:   # 방이 비어있지 않으면
                name = rooms[floor-1][room-1]
                rooms[floor-1][room-1] = 0
                save_rooms()
                print(f"{floor}층 {room}호 [{name}]퇴실 완료!\n")
            else:
                print("이미 빈 방입니다!\n")

        elif first == 4:  # 종료
            save_rooms()
            print("프로그램을 종료합니다. 현재 상황을 저장합니다.")
            break

        else:
            print("1~4 중에서 선택해주세요.\n")

if __name__ == "__main__":
    main()                      #이거 안 쓰면 4.종료 선택 후 새로 실행하면 1.조회 ~ 창이 안 뜹니다. 원인은 모릅니다. 코드를 짰을 때부터 메인함수랑 연결된채 짜서 그런 것 같습니다.

# 처음에 다 일일이 썼다가 마지막 코드가 기억 안 나서 이것 포함 코드 10개미만 참고했습니다.