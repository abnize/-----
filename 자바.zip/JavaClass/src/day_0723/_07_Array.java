package day_0723;

public class _07_Array {
    public static void main(String[] args) {

        String a = "똘기";
        String b = "떵이";
        String c = "호치";
        String d = "새촘이";
        String e = "드라곤";
        String f = "요롱이";
        String g = "마초";
        String h = "미미";
        String i = "뭉치";
        String j = "키카";
        String k = "강다리";
        String l = "찡찡이";

        System.out.println("토끼와 거북이 동화에 문제가 생겼다.");
        System.out.println(g + " 출동");
        System.out.println(l + " 출동");
        System.out.println(d + " 출동");
        System.out.println(f + " 출동");

        String[] ggurugi = {"똘기", "떵이", "호치", "새촘이", "드라곤"};
        System.out.println(ggurugi[0] + " 출동");
        System.out.println(ggurugi[1] + " 출동");
        System.out.println(ggurugi[2] + " 출동");

        for (int m = 0; m < 5; m++) {
            System.out.println(ggurugi[m] + " ");
        }

        int[] number = new int[3];
        number[0] = 1;
        number[1] = 5;
        number[2] = 7;

        int[] intArray = new int[5];
        String[] strArray = new String[5];

        int[] varArray = {1, 2, 3, 4, 5};

        System.out.println("intArray[0] = " + intArray[0]);
        System.out.println("intArray[1] = " + intArray[1]);

        System.out.println("strArray[0] = " + strArray[0]);
        System.out.println("strArray[1] = " + strArray[1]);

        System.out.println("varArray[0] = " + varArray[0]);
        System.out.println("varArray[1] = " + varArray[1]);

        // 배열의 길이
        System.out.println(intArray.length);
        System.out.println(strArray.length);
        System.out.println(number.length);
    }
}
