package day_0723;

public class _06_Break {
    public static void main(String[] args) {
        int max = 15;
        int sold = 0;
        int noShow = 7;

        for (int i = 1; i <= 100; i++) {
            // 7번 손님은 따로 처리
            if (i == noShow) {
                while (true) {
                    System.out.println(i + "번 손님 치킨 나왔습니다 ~~");
                    sold++;  // 치킨 판매
                    break;   // 한 번 출력 후 종료
                }

                if (sold == max) {
                    System.out.println("오늘 장사 끝났습니다.");
                    break;
                }

                continue; // 다음 손님으로 이동
            }

            // 나머지 일반 손님 처리
            System.out.println(i + "번 손님 치킨 나왔습니다.");
            sold++;

            if (sold == max) {
                System.out.println("오늘 장사 끝났습니다.");
                break;
            }

            while (true) {
                break; // 기존 구조 유지
            }
        }
    }
}
