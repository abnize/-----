package day_0723;

import java.util.Arrays;

public class _10_Arrays {
    public static void main(String[] args) {
        int[] arr = {1,2,4,6,8,9};

        System.out.println("날 것 그대로: " + Arrays.toString(arr));
        Arrays.sort(arr);
        System.out.println("정렬 후: " + Arrays.toString(arr));

        int[] arr01 = {1,2,3};
        int[] arr02 = arr01;

        arr02[1] = 10;

        System.out.println("arr01 배열: " + Arrays.toString(arr01));
        System.out.println("arr02 배열: " + Arrays.toString(arr02));

        int[] arr03 = {1,2,3};
        int[] arr04 = Arrays.copyOf(arr03, arr03.length);

        arr03[2] = 10;

        System.out.println("arr03 배열: " + Arrays.toString(arr03));
        System.out.println("arr04 배열: " + Arrays.toString(arr04));

    }
}
