package day_0723;

public class _04_DpWhile {
    public static void main(String[] args) {

        int sum = 0;
        int i = 1;

        do {
            System.out.println("안녕해");
        }while (i>=10);
//        System.out.println(sum);
    }
}
