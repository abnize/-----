package day_0723;

import java.lang.reflect.Array;
import java.util.Arrays;

public class _09_Lotto {
    public static void main(String[] args) {

        Integer[] mynumber = new Integer[6];
        int count = 0;

        while (true) {
        for (int i = 0; i< mynumber.length;) {
            int rand = (int)(Math.random()*45) + 1;

            boolean isDuplicate = false;
            for (int j = 0; j < i; j++) {
                if (mynumber[j] == rand) {
                    isDuplicate = true;
                    break;
                }
            }

            if (!isDuplicate) {
                mynumber[i] = rand;
                i++;
            }
        }

        Arrays.sort(mynumber);

        for (int i = 0; i< mynumber.length; i++) {
            System.out.print(mynumber[i] + " ");
        }
        System.out.println();

        count++;

             if(mynumber[0] == 6 &&
                mynumber[1] == 11 &&
                mynumber[2] == 17 &&
                mynumber[3] == 33 &&
                mynumber[4] == 39 &&
                mynumber[5] == 42 ) {

                System.out.println(" 총 시도 횟수 : " + count);
                break;
                }
            }
        }
    }