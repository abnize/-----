package day_0723;

public class _08_Array2 {
    public static void main(String[] args) {

        //numbers 정수 어레이 10 칸짜리
        int[] numbers = new int[10];
        int count = 0;

        while (true) {
        for (int i = 0; i < numbers.length; i++) {    //1~30 사이 숫자 채움 10개
            numbers[i] = (int) (Math.random() *30) + 1;
        }
            int sum = 0;
            for (int i = 0; i < numbers.length; i++) {//하나씨 조회해 짝수만 걸러 누적 더함

                if (numbers[i] % 2 == 0) {
                    sum += numbers[i];
                }
            }

            for (int i = 0; i < numbers.length; i++) { //10개숫자뽑기
                System.out.print(numbers[i] + " ");
            }
            System.out.println("==> " + sum);//누적 함 뽑아 보기'

            count++;
            if (sum == 0) {
                System.out.println("총 시도 횟수 : " + count + " 번");
                break;
            }
            // while 문으로 감싸서 자동으로 계속 실행시켜 sum = 0 나올때 까지 총 몇 번 시도했는지까지 뽑아보기
        }
    }
}