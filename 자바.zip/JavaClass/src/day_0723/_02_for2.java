package day_0723;

public class _02_for2 {
    public static void main(String[] args) {

        int count = 0;

        for (int i = 1; i <= 5; i++) {  //몇 번 방

            for (int j = 1; j <= 5; j++) {
                System.out.println("안녕하세요" + i + " 번 방" + j + "번 형님");  // 몇 번 형님
                count++;
            }
        }
        System.out.println("오늘도 보람차게 인사를 " +count + " 번 하였다.") ;

            for (int i = 0; i < 10; i++) {
                for (int j=0; j<=i; j++) {
                    System.out.print( "");  // 몇 번 형님
                }
            count++;
        }











            System.out.println();
            System.out.println("============== 세로 구구단 =============");

                    for (int i = 1; i <= 9; i++) {
                        for (int dan = 2; dan <= 9; dan++) {
                        System.out.print(dan + "x" + i + "=" + (dan * i)+"\t");
                    }
                    System.out.println();
        }

        System.out.println();
        System.out.println("============== 가로 구구단 =============");

        for (int dan = 2; dan <= 9; dan++) {
            for (int i = 1; i <= 9; i++) {
                if (i == 1) {
                System.out.print("[" + dan + "단] ");
            }else{
                System.out.print(" ");
            }
            System.out.print(dan + "x" + i + "=" + (dan * i)+"\t");
            }
            System.out.println();
        }

        System.out.println();
        System.out.println("============== @ 왼쪽 정렬 피라미드 =============");

        for (int i = 1; i <= 7; i++){
            for (int j = 1; j <= i; j++){
                System.out.print("@");
            }
            System.out.println();
        }

        System.out.println();
        System.out.println("============== @ 오른쪽 정렬 =============");

        for (int i = 1; i <= 7; i++) {
            for (int j = 7; j > i; j--) {
                System.out.print(" ");
            }
            for (int k = 1; k <= i; k++) {
                System.out.print("@");
            }
            System.out.println();
        }
            System.out.println();
            System.out.println("============== @ 역방향 피라미드 =============");

                for (int i = 7; i >= 1; i--) {
                for (int j = 1; j <= i; j++) {
                    System.out.print("@");
                }
                System.out.println();
            }
        System.out.println();
        System.out.println("============== @ 중앙 피라미드 =============");

        for (int i = 1; i<= 7; i++){
            for (int j = 7; j > i; j--){
                System.out.print(" ");
            }
            for (int k = 1; k<=(2*i-1);k++){
                System.out.print("@");
            }
            System.out.println();
        }

        System.out.println();
        System.out.println("============== @ 다이아몬드 피라미드(붙임용) =============");

        for (int i = 1; i<= 7; i++){
            for (int j = 7; j > i; j--){
                System.out.print(" ");
            }
            for (int k = 1; k<=(2*i-1);k++){
                System.out.print("*");
            }
            System.out.println();}
            for (int i = 7; i>= 1; i--){
                for (int j = 7; j > i; j--){
                    System.out.print(" ");
                }
                for (int k = 1; k<=(2*i-1);k++){
                    System.out.print("*");

                }
            System.out.println();
        }

        System.out.println();
        System.out.println("============== @ 다이아몬드 피라미드(안 붙임용) =============");

        for (int i = 1; i <= 13; i++) {
            int n = i <= 7 ? i : 14 - i;
            for (int j = 1; j <= 7 - n; j++)
            System.out.print(" ");
            for (int j = 1; j <= 2 * n - 1; j++)
                System.out.print("*");
            System.out.println();
        }

    }
}



