package day_0718;

public class _01_Start {
    public static void main (String[] args) {
        System.out.println("Hello, java World");
        System.out.println("Hi, java World");
        System.out.println("Hey, java World");
    }

}
