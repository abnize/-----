package day_0718;

public class _05_Comment {
    public static void main(String[] args) {
        System.out.printf("(5분) 일찍 오기");
        // 하지만 비가 와서 힘들죠, 그렇죠?

        int size = 120;
        size = size + 10;
        System.out.println("사이즈는 " + size + " 입니다. ");

        int a = 10;
        int b = 20;
        int c = 30;

        System.out.printf("a+b");


    }
}

