package day_0718;

public class _04_Zquiz {
    public static void main(String[] args) {
        String food = "김밥, 떡볶이, 순대";
        String hs = "호모사피엔스";
        String tr = "true";


        System.out.println("이름 : 김자바");
        System.out.println("나이 : 20");
        System.out.println("키 : 172.5 cm");
        System.out.println("성별 : M");

        System.out.println("제가 좋아하는 음식은 " + food + "입니다.");

        System.out.println("당신은 " + hs + " 입니까? 네. 그것은 " + tr + " 입니다.");








    }
}
