package day_0718;

public class _03_Variables_java {
    public static void main(String[] args) {
        String love = "좋아해";
        System.out.println("그런 나를 너는 좋아해?" + love);
        
        double d = 175.6;
        float e = 133.33333F;
        System.out.println(d);
        System.out.println(e);

        long i = 100000000000000L;
        System.out.println(i);
    }
}