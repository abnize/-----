package day_0718;

public class _07_Constants {
    public static void main(String[] args) {
        final String KR_COUNTRY_CODE = "+82";

        final double PI = 3.141592; // 원주율
        final String DATE_OF_BRITH = "2001-07-18";

    }
}
