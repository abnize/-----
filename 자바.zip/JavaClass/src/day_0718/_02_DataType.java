package day_0718;

public class _02_DataType {
    public static void main(String[] args) {
        System.out.println("When I wasn young I listen to the radio");
        System.out.println("난 어릴 적 라디오를 듣곤 했어.");
        System.out.println("주파수 13246-2223556가 내 최애 방송전파였지.");
        System.out.println(12);
        System.out.println(-55);
        System.out.println(2.44);
        System.out.println(true);
        System.out.println(false);
        System.out.println(5 + 6);
    }
}