package day_0718;

public class _06_VariableNaming {
    public static void main(String[] args) {
        /*변수 이름 짓기
        1. 저장할 값에 어울리는 이름
        2. 밑줄, 문자, 숫자 사용가능(공백은 불가)
        3. 시작은 밑줄 또는 문자 ( 숫자 불가)
        4. 한 단어 또는 2개 이상 단어의 연속
        5. 소문자로 시작 두 번쨰 단어의 첫글자는 대문자
        6. 혹은 여러단어를 언더바로 연결
        7. 예약어는 사용 X (public, static, void, d)*/

        String nationality= "대한민국";
        String firstname= "이름";
        String lastname= "성";
        String dateOfBirth = "2001-07-18";
        String residentialAddress = "라마호텔";
        String purposeOfVisit = "business";
        String flightNo = "KE234";
        String flightNo2 = "ER345";
        String _flightNo = "ER345";

        String item1 = "핸드폰";
        String item2 = "여권";
        //String 3item = "헤드셋";

        // 절대 변하지 않는 상수는 대문자로
        final String CODE = "KR";

        System.out.printf("국가 코드는: " + CODE + "입니다.");
    }
}
