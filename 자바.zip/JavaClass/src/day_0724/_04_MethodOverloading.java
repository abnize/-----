package day_0724;

public class _04_MethodOverloading {
    public static void main(String[] args) {

        BlackBox b1 = new BlackBox();
        b1.modelName = "까망";

        b1.record(false, false, 10);
        System.out.println("====================");
        b1.record(false, false, 5);
        System.out.println("====================");
        b1.record(false, false, 3);
        System.out.println("====================");
        b1.record();

    }
}