package day_0724;

public class _08_GetterSetter {
    public static void main(String[] args) {
        BlackBox b1 = new BlackBox();
        b1.setModelName("까망");
        b1.setPrice(200000);
        b1.color = "블랙";

        //할인행사 ~~

        System.out.println("가격: "+b1.getPrice() + "원");
        b1.setPrice(b1.getPrice()-50000);
        System.out.println("가격: "+b1.getPrice() + "원");

        System.out.println("화질은 " +  b1.getResolution());

        BlackBox.callServiceCenter();

        System.out.println("===================");
    }
}
