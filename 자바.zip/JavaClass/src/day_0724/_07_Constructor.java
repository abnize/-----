package day_0724;

public class _07_Constructor {
    public static void main(String[] args) {
        BlackBox b1 = new BlackBox();
        b1.modelName = "까망";
        b1.resolution = "FHD";
        b1.price = 200000;
        b1.color = "블랙";
        System.out.println(b1.modelName);
        System.out.println(b1.serialNumber);

        System.out.println("======================");

        BlackBox b2 = new BlackBox();
        BlackBox b3 = new BlackBox();
        BlackBox b4 = new BlackBox();
        BlackBox b5 = new BlackBox();

        System.out.println("======================");

        BlackBox b6 = new BlackBox("핑킁이", "UHD", 300000, "분홍");
        System.out.println(b1.modelName);
        System.out.println(b1.resolution);
        System.out.println(b1.price);
        System.out.println(b1.color);
        System.out.println(b1.serialNumber);

        System.out.println("총 출고 대수: " + BlackBox.counter);
    }
}
