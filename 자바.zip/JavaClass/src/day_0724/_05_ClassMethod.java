package day_0724;

public class _05_ClassMethod {
    public static void main(String[] args) {
        BlackBox.callServiceCenter();

        // 되기만 할 뿐 취지에 맞지 않다.
//        BlackBox b1 = new BlackBox();
//        b1.callServiceCenter();
    }
}
