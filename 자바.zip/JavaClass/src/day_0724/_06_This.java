package day_0724;

public class _06_This {
    public static void main(String[] args) {
        BlackBox b1 = new BlackBox();
        b1.modelName = "까망"; //까망(최신버전)
        b1.appendModelName("(최신버전)");
        System.out.println(b1.modelName);

    }
}
