package day_0724;

public class Dog {

    private String name;
    int age;
    static String bark= "멍멍";
    static int count;

    public Dog() {}

    public Dog(String name, int age) {  // 생성자 (기본 세팅)
        this.name = name;
        this.age = age;
    }
//    public void setName(String name)

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if(age >= 1) {
            this.age = age;
        }else {
            System.out.println("나이는 1살부터 입력 가능!!");
        }
    }

    public void weare() {
        System.out.println("우리는 강아지 입니다."); //우리는 군단이다.
    }

    public void introduce() {
        System.out.println("지금부터 제 소개를 하겠습니다.");
        System.out.println("이름은 "+this.name+" 나이는 "+this.age+"살 입니다.");
        count++;
    }


}
