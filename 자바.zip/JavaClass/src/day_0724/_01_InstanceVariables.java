package day_0724;

public class _01_InstanceVariables {
    public static void main(String[] args) {
        BlackBox b1= new BlackBox();
        b1.modelName = "까망";
        b1.resolution = "FHD";
        b1.price = 200000;
        b1.color = "블랙";

        // 모델이름, 화질, 가격, 색상 출력 해보기
        System.out.println(b1.modelName);
        System.out.println(b1.resolution);
        System.out.println(b1.price);
        System.out.println(b1.color);

    }
}
