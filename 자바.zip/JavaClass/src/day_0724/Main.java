package day_0724;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Dog dog1 = new Dog("누렁이", 3);
        Dog dog2 = new Dog("바둑이", 2);
        Dog dog3 = new Dog("흰둥이", 8);
        Dog dog4 = new Dog("뽀삐", 4);
        Dog dog5 = new Dog("사탕이", 13);
        Dog dog6 = new Dog("기쁨이", 7);

        Cat cat1 = new Cat("미미", 5);
        Cat cat2 = new Cat("양이", 1);
        Cat cat3 = new Cat("나비", 10);
        Cat cat4 = new Cat("하양이", 6);
        Cat cat5 = new Cat("사라", 3);
        Cat cat6 = new Cat("김창식", 9);

        Scanner sc = new Scanner(System.in);

        dog1.introduce();
        dog2.introduce();
        dog3.introduce();
        dog4.introduce();
        dog5.introduce();
        dog6.introduce();
        System.out.println("=====================");
        cat1.introduce();
        cat2.introduce();
        cat3.introduce();
        cat4.introduce();
        cat5.introduce();
        cat6.introduce();
        System.out.println("=====================");
        dog1.weare();
        dog2.weare();
        dog3.weare();
        dog4.weare();
        dog5.weare();
        dog6.weare();
        System.out.println("=====================");
        cat1.weare();
        cat2.weare();
        cat3.weare();
        cat4.weare();
        cat5.weare();
        cat6.weare();
        System.out.println("=====================");
        System.out.println("누렁이의 나이는 " + dog1.age + "살");

        System.out.println("자기 소개 횟수: " +Dog.count);

        Cat nabi = cat3;
        nabi.cry();
        nabi.introDream("대통령");

        int unga = nabi.feedUnga(3);
        System.out.println("결론적으로 엉가 횟수는: " + unga);

        unga = nabi.feedUnga(4,4);
        System.out.println("밥먹고 물마시고 엉가 횟수는: " + unga);
    }
}
