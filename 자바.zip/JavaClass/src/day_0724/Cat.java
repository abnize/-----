package day_0724;

public class Cat {

    String name;
    int age;
    private String bob;

    public Cat(String name, int age) {  // 생성자 (기본 세팅)
        this.name = name;
        this.age = age;
    }

    public void weare() {
        System.out.println("우리는 고양이다."); //우리는 군단이다.
    }

    void talk() {
        System.out.println("반갑습ㄴ디ㅏ.");
    }


    public void introduce() {
        System.out.println("자기소개를 하겠다. 잘 들어라.");
        System.out.println("이름은 " + this.name + " 나이는 " + this.age + "살 이다.");
    }

    void cry() {
        System.out.println("야옹양옹");
    }

    void introDream(String dream) {
        System.out.println(name + "의 꿈은" + dream + "입니다.");
    }

    int feedCount(int bab) {
        System.out.println("밥을 " + bob + " 번 먹었으므로  저의 오늘 화장실 횟수는!! ");
        System.out.println("직접 확인해보세요");
        int unga = bab * 2;
        return unga;
    }

    // 파라미더 캐수가 다르거나 자료형이 다르거나 순서가 다르거나
    int feedUnga(int bob, int mool) { //메서드 오버라이딩
        System.out.println("저는 " + name + "인데요");
        System.out.println("밥을 " + bob + " 물을 " +mool+ " 번 먹었죠" );
        return bob + mool;
    }

    public int feedUnga(int i) {
        return i;
    }
}

