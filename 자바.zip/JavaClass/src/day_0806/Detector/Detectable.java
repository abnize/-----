package day_0806.Detector;

public interface Detectable {
    void detect();

}
