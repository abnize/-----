package day_0806.Detector;

public class AccidentDetector implements Detectable {
    public void detect() {
        System.out.println("사고를 감지합니다.");
    }
}
