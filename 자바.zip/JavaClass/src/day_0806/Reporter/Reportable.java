package day_0806.Reporter;

public interface Reportable {
    void report();
}
