package day_0806.Phone;

public class ThreeStarPhone extends Phone {
    @Override
    void openingLogo() {
        System.out.println("🔴🟢🟡");
    }
}
