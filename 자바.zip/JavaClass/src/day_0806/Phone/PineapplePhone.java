package day_0806.Phone;

public class PineapplePhone extends Phone {
    @Override
    void openingLogo() {
        System.out.println("🖤💜🤍");
    }
}
