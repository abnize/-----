package day_0806;

import java.util.Scanner;

abstract class Menu {
    String name;
    int price;

    public Menu(String name, int price) {
        this.name = name;
        this.price = price;
    }

    public abstract void order();
}
    class Chicken extends Menu {
        public Chicken() {
            super("치킨", 17000);
        }
        @Override
        public void order() {
            System.out.println(name + "(" + price + ") 을 주문합니다. 양념 소스를 선택하셨습니다.");
        }
    }

    class Pizza extends Menu {
        public Pizza() {
            super("피자", 15000);
        }
        @Override
        public void order() {
            System.out.println(name + "(" + price + ") 을 주문합니다. 도우 는 얇은 걸로 선택되었습니다.");
        }
    }

    class Jokbal extends Menu {
        public Jokbal() {
            super("족발", 25000);
        }
        @Override
        public void order() {
            System.out.println(name + "(" + price + ") 을 주문합니다. 마늘 소스와 '쌈 채소 많이' 를 선택하셨습니다.");
        }
    }

    public class DeliveryApp {
        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
            int total = 0;
            while (true) {
                System.out.println("\n === 메뉴를 선택하세요. ===");
                System.out.println("1. 치킨");
                System.out.println("2. 피자");
                System.out.println("3. 족발");
                System.out.println("0. 종료");
                System.out.print("선택: ");

                int choice = sc.nextInt();
                Menu menu = null;

                switch(choice) {
                    case 1:
                        menu = new Chicken();
                        break;
                    case 2:
                        menu = new Pizza();
                        break;
                    case 3:
                        menu = new Jokbal();
                        break;
                    case 0:
                        System.out.println("주문이 종료되었습니다. 감사합니다!");
                        System.out.println("총 결제 금액: " + total + "원");
                        System.out.println("결제수단을 선택해주세요.");
                        return;
                    default:
                        System.out.println("있는 번호로 다시 입력해주시길 바랍니다. 감사합니다. ");
                        continue;
                }
                menu.order();
                total+=menu.price;
        }
    }
}
