package day_0806;

import day_0806.Detector.AdvancedFireDetector;
import day_0806.Detector.Detectable;
import day_0806.Detector.FireDetector;
import day_0806.Camera.FactoryCam;
import day_0806.Reporter.NormalReporter;
import day_0806.Reporter.Reportable;
import day_0806.Reporter.VideoReporter;

public class _02_Interface {
    public static void main(String[] args) {

        FireDetector fd = new FireDetector();
        fd.detect();

        Detectable afd = new AdvancedFireDetector();
        afd.detect();

        System.out.println("========================");

        NormalReporter nr = new NormalReporter();
        nr.report();

        Reportable vr = new VideoReporter();
        vr.report();

        System.out.println("=======================");

        FactoryCam fc = new FactoryCam();
        fc.setDetector(fd);
        fc.setReporter(nr);

        fc.detect();
        fc.report();
    }
}
