// Speak.java
package day_0806.MultiInterface;

public interface Speaker {
    void music();
}
