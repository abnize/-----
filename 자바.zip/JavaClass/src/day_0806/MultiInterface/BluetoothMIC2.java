package day_0806.MultiInterface;

public class BluetoothMIC2 implements Microphone, Speaker {
    public void connect() {
        System.out.println("🔵 BluetoothMIC2 연결 완료!");
    }

    @Override
    public void sing() {
        System.out.println("🎤 BluetoothMIC2로 노래 부릅니다.");
    }

    @Override
    public void music() {
        System.out.println("🎶 BluetoothMIC2로 음악을 재생합니다.");
    }
}
