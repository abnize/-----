package day_0806.MultiInterface;

public class TJmic extends BluetoothMIC2 {
    @Override
    public void connect() {
        System.out.println("🟢 TJmic 연결 완료!");
    }

    @Override
    public void sing() {
        System.out.println("🎤 TJmic으로 신나게 노래합니다.");
    }

    @Override
    public void music() {
        System.out.println("🎶 TJmic으로 고음질 음악 재생!");
    }
}
