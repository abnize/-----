package day_0806.MultiInterface;

public class Main {
    public static void main(String[] args) {
        BluetoothMIC bm = new BluetoothMIC();

        bm.music();
        bm.sing();

        Microphone m = bm;
        m.sing();
        // m.music();

        Speaker s = bm;
        // s.sing();
        s.music();

    }
}
