// BluetoothMIC.java
package day_0806.MultiInterface;

public class BluetoothMIC implements Microphone, Speaker {
    @Override
    public void sing() {
        System.out.println("🎤 마이크로 노래를 부릅니다!");
    }

    @Override
    public void music() {
        System.out.println("🎵 음악을 재생합니다!");
    }
}
