// Microphone.java
package day_0806.MultiInterface;

public interface Microphone {
    void sing();
}
