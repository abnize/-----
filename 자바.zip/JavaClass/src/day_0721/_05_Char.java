package day_0721;

public class _05_Char {
    public static void main(String[] args) {
        char ga = '가';
        char a = 'A';

        System.out.println(ga);
        System.out.println(a);

        int na = '나';
        int b = 'B';

        System.out.println(na);
        System.out.println(b);
    }
}
