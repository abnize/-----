package day_0721;

public class _15_Operator5 {
    public static void main(String[] args) {

        int num = (7 > 1)? 1 : 2 ;
        System.out.println(num);

        int x = 100;
        int y = 5;

        int max = (x > y) ? x : y ;
        System.out.println(max);

        int min = (x < y) ? x : y ;
        System.out.println(min);


        //놀이공원 무게  > 120 이면 탑승 가능, 아니면 탑승 불가
        // 무게 = 130
        // 무게 = 110
        int height = 110;
        int height2 = 130;

        String result = (height > 120) ?  "탑승 가능" : "탑승 불가";
        String result2 = (height < 120) ? "탑승 가능" : "탑승 불가";

        System.out.println("무게: " + height + "kg → " + result);
        System.out.println("무게: " + height2 + "kg → " + result2);

    }
}
