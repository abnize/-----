package day_0721;

public class _11_Print {
    public static void main(String[] args) {
        System.out.printf("무하하하");
        System.out.printf("무야호~~");

//        System.out.print("무한 ");
//        System.out.print("도전 ");
//        System.out.print("일박 ");
//        System.out.print("이일 ");

        System.out.print("안녕 ");
        System.out.println("길동아");
        System.out.print("행복해 ");
        System.out.println("보이는구나 ");
        System.out.print("즐거워 ");
        System.out.println("보이니 좋다");
        System.out.print("잘 살아 ");

        System.out.println("새로운 내용 시작");
    }
}
