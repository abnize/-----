package day_0721;

public class _02_Variable {
    public static void main(String[] args) {
        String name;
        String age;
        char bloodType;

        name = "홍길동";
        age = "20";
        bloodType = 'B';

        System.out.println(name);
        System.out.println(age);
        System.out.println(bloodType);

    }
}
























































