package day_0721;

public class _04_DataType {
    public static void main(String[] args) {
        //
         //
         //
         //

        int a = 30;
        byte age = 100;
            // byte age2 = 128;
        short b = 32767;
        short c = (short) 32768;

        System.out.println("b");
        System.out.println("c");

        //소수표현
        // float 정밀도 7자리
        // double 정밀도 15자리

        double marathon = 42.195;
        float halfMarathon = 21.0975f;

        System.out.println("마라톤은"  + marathon + "km를 달립니다");
        System.out.println("하프 마라톤은  "   + halfMarathon + "km를 달립니다");

        double pieDouble = 3.141595653589793f;
        float pieFloat = 3.1415927f;

        double d1 = 1.0e100;
        double d2 = 1.0e100;
        float f1 = 1.0e-10f;

        System.out.println("double 지수 표현: " + d1);
        System.out.println("float 지수 표현: " + f1);



    }
}
