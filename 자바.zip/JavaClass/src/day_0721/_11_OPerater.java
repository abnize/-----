package day_0721;

public class _11_OPerater {
    public static void main(String[] args) {
        int x = 100;
        int plusX = +x;
        int minusX = -x;

        System.out.println(plusX); //100
        System.out.println(minusX); //-100

        double d = 1.11;
        double result = -d;

        System.out.println(-d); //-1.11
        System.out.println(result); //-1.11
    }
}
