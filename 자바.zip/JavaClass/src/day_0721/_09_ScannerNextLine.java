package day_0721;

import java.util.Scanner;

public class _09_ScannerNextLine {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("오늘의 기분은 어떤가요.");
        String today = sc.nextLine();
        System.out.println("응답: " + today);

        System.out.println("어제의 기분은 어땠나요?");
        String yesterDay = sc.nextLine();
        System.out.println("응답: " + yesterDay);
    }
}
