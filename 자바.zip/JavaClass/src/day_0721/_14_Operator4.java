package day_0721;

public class _14_Operator4 {
    public static void main(String[] args) {













        System.out.println(5 > 3);  //true
        System.out.println(5 <= 3);  //false
        System.out.println(5 != 3);  //true

        boolean b1 = true;
        boolean b2 = false;
        boolean b3 = true;
        boolean b4 = false;

        System.out.println("======논리곱========");
        System.out.println(b1 && b2);   //false
        System.out.println(b1 && b3);   //true
        System.out.println(b2 && b4);   //false
        System.out.println();

        System.out.println(b1 && b2 && b3);


        System.out.println("======논리합========");
        System.out.println(b1 || b2);   //true
        System.out.println(b1 || b3);   //true
        System.out.println(b2 || b4);   //false
        System.out.println();

        System.out.println(b1 || b2 || b3); // true

        System.out.println("======배타적 논리합========");
        System.out.println(b1 || b2);   //true
        System.out.println(b1 || b3);   //true
        System.out.println(b2 || b4);   //false 수정 못 함
        System.out.println();
    }
}
