package day_0721;

import java.util.Scanner;

public class _10_Quiz {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("무슨 언어를 배우세요?");
        String answer1 = sc.nextLine();


        System.out.println("기분이 어떠세요");
        String answer2 = sc.nextLine();

        System.out.println(answer1 + "를 배우니 " + answer2 + "입니다.");
    }
}
