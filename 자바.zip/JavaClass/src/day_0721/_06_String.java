package day_0721;

public class _06_String {
    int a = 20;
    char b = 'B';

    String c = "이것은 긴 글을 저장할 수 있는 스트링입니다.";
}
