package day_0721;

public class _12_Operator2 {
    public static void main(String[] args) {
        int num = 10;
        System.out.println(num);    //10
        num++;
        System.out.println(num);

        int age = 30;
        System.out.println(age++);  //30+1
        System.out.println(age);    //31

        int abc = 5;
        System.out.println(++abc);  //1 더하고 출력

        int x = 1;
        System.out.println(x++);    // 1 -> 2
        System.out.println(x);      // 2
        System.out.println(++x);    // -> 3 출력

        x = 10;
        System.out.println(x);  //10
        System.out.println(--x);    //9
        System.out.println(x);  //
        System.out.println(x--);    //

        int a = 'X';    //유니코드
        System.out.println(a);  //88
        int b = 'Y';
        System.out.println(b);  //89

        char alphabet_x = 'X';
        System.out.println(alphabet_x); // X
        System.out.println(++alphabet_x);   // Y

        boolean isHuman = false;
        System.out.println(isHuman);
        System.out.println(!isHuman);

    }
}
