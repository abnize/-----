package day_0721;

import java.util.Scanner;

public class _08_Scanner {
    public static void main(String[] args) {
//        int age = 32;

        Scanner sc = new Scanner(System.in);

        String name;
        String address;
        int age1;
        double height;

        System.out.printf("이름, 주소, 나이, 키를 띄어쓰기로 입력하세요(엔터아님)");
        name = sc.next();
        address = sc.next();
        age1 = sc.nextInt();
        height = sc.nextDouble();

        System.out.printf("제 이름은 %s 입니다.%n", name);
        System.out.printf("제 주소는 %s 입니다.%n", address);
        System.out.printf("제 나이는 %s 입니다.%n", age1);
        System.out.printf("제 키는 %s 입니다.%n", height);

    }
}
