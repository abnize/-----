package day_0805;

class Animal2 {
    void cry() {}
}

class Pig2 extends Animal2 {
    @Override
    void cry() {
        System.out.println("꿀꿀");
    }
}

class Cow2 extends Animal2 {
    @Override
    void cry() {
        System.out.println("음매");
    }
}


class Farm2 {
    void sound(Animal2 animal2) {
        animal2.cry();
    }
}

public class _04_CheckByMethod {
    public static void main(String[] args) {
        Farm2 f2 = new Farm2();
        Pig2 p2 = new Pig2();
        Cow2 C2 = new Cow2();
    }
}