package day_0805.Bike;

public class Main {
    public static void main(String[] args) {
        Bike b = new FourWheelBike("길동");
        b.info();
        b.ride();
        // b.addWheel(); <==안 됨

        System.out.println("=============");

        FourWheelBike fwb = (FourWheelBike) b;
        fwb.addWheel();
        fwb.info();
        fwb.ride();

        // 모든 부모타입 객체를 자식탑으로 변환 가능 한 건 아님
    }
}
