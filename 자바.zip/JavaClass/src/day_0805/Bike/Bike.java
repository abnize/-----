package day_0805.Bike;

public class Bike {
    protected String riderName;
    protected int wheel;

    public Bike(String riderName) {
        this.riderName = riderName;
        this.wheel = 2;  // 기본은 2발 자전거
    }

    void info() {
        System.out.println(riderName + "의 자전거는 " + wheel + "발 자전거입니다.");
    }

    void ride() {
        System.out.println("씽씽");
    }
}
