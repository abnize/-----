package day_0805;

public class FastFood2 {
    public static void main(String[] args) {
        Hamburger2[] hamburgers2 = new Hamburger2[3];
        hamburgers2[0] = new Hamburger2();
        hamburgers2[1] = new Shrimpburger2();
        hamburgers2[2] = new Cheeseburger2();

        for (Hamburger2 hamburger2 : hamburgers2) {
            System.out.println("===========");
            hamburger2.cook();
            System.out.println("===========");
        }
    }
}

    class Hamburger2{
        protected String name;

        public Hamburger2() {this("햄버거");}

        public Hamburger2 (String name) {this.name = name;}

        public void cook() {

            System.out.println("양상추");
            System.out.println("패티");
        }
    }

    class Shrimpburger2 extends Hamburger2 {
        String shrimp = "새우";

        public Shrimpburger2 () { super("새우버거");}

        @Override
        public void cook() {
            super.cook();
            System.out.println(shrimp+" 추가");
        }
    }

    class Cheeseburger2 extends Hamburger2 {
        String Cheese = "치즈";

        public Cheeseburger2 () { super("치즈버거");}

        @Override
        public void cook() {
            super.cook();
            System.out.println(Cheese+" 추가");
        }
}
