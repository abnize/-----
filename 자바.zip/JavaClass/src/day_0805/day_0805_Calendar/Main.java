package day_0805.day_0805_Calendar;

public class Main {
    public static void main(String[] args) {

        DeskCalendar dc = new DeskCalendar("무지개색", 8);
        dc.info();
        dc.hanging();
        dc.onTheDesk();

        System.out.println("===============");

        Calendar c = new DeskCalendar("투명색", 12);
        c.info();
        c.hanging();
        // c.onTheDesk(); ====> 자식에게만 있는 메서드라서 사용 불가
    }
}
