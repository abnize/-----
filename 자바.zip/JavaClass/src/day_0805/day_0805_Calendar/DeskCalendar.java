package day_0805.day_0805_Calendar;

public class DeskCalendar extends Calendar{

    DeskCalendar(String color, int months) {
        super(color, months);
    }

    @Override
    void hanging() {
        System.out.println(color + "달력은 벽에 걸려면 추가 고리 필요");
    }

    void onTheDesk() {
        System.out.println(color + "달력을 벽실에 세울 수 있습니다.");
    }
}
