package day_0805.day_0805_Calendar;

public abstract class Calendar {
    String color;
    int months;

    Calendar(String color, int months) {
        this.color = color;
        this.months = months;
    }

    void info() {
        System.out.println(color + " 달력은 " + months + " 월까지 있습니다.");
    }

    abstract void hanging();
}
