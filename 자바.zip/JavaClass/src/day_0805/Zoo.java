package day_0805;

class Dog {
    public void makeSound() {
        System.out.println("멍멍!");
    }
}

class Cat {
    public void makeSound() {
        System.out.println("먀앍!");
    }
}

class Sheep {
    public void makeSound() {
        System.out.println("매애!");
    }
}

public class Zoo {
    public static void main(String[] args) {
        Dog dog = new Dog();
        Cat cat = new Cat();
        Sheep sheep = new Sheep();

        playDogSound(dog);
        playCatSound(cat);
        playSheepSound(sheep);

    }

    public static void playDogSound(Dog dog) {
        dog.makeSound();
    }
    public static void playCatSound(Cat cat) {
        cat.makeSound();
    }
    public static void playSheepSound(Sheep sheep) {
        sheep.makeSound();
    }
}
