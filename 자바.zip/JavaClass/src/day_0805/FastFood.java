package day_0805;

    class Hamburger {
        public void cook() {
            System.out.println("햄버거 재료");
            Original();
        }

        protected void Original() {
            System.out.println("양상추");
            System.out.println("패티");
        }
    }

    class ShrimpBurger extends Hamburger {
        @Override
        public void cook() {
            System.out.println("새우버거 재료");
            super.Original(); // 부모의 기본 재료 출력
            System.out.println("새우 추가");
        }
    }


    class CheeseBurger extends Hamburger {
    @Override
    public void cook() {
        System.out.println("치즈버거 재료");
        super.Original(); // 부모의 기본 재료 출력
        System.out.println("치즈 추가");
    }
}

public class FastFood {
    public static void main(String[] args) {
        Hamburger[] hamburgers = {
                new Hamburger(),
                new ShrimpBurger(),
                new CheeseBurger()
        };

        for (Hamburger hamburger : hamburgers) {
            System.out.println("===========");
            hamburger.cook();
            System.out.println("===========");
        }
    }
}