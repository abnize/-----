package day_0805;

import day_0804.Camera.ActionCam;
import day_0804.Camera.SlowActionCam;

public class _08_Final {
    public static void main(String[] args) {
        //final
        ActionCam actionCam = new ActionCam();
        // actionCam.lens = "표준렌즈"; -- 파이널 필드라서 바꿀 수 없다!
        actionCam.recordVideo();
        actionCam.makeVideo();

        System.out.println("====================");

        SlowActionCam slowActonCam = new SlowActionCam();
        SlowActionCam slowActionCam = new SlowActionCam();
        slowActionCam.recordVideo();
        slowActonCam.makeVideo();
    }
}
