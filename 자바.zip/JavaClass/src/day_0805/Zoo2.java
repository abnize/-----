package day_0805;

class Animal4 {
    public void sound() {}
}

class Dogg extends Animal4 {
    @Override
    public void sound() {
        System.out.println("멍멍!");
    }
}

class Catt extends Animal4 {
    @Override
    public void sound() {
        System.out.println("먀앍!");
    }
}

class Sheepp extends Animal4 {
    @Override
    public void sound() {
        System.out.println("매 애!");
    }
}

public class Zoo2 {
    public static void main(String[] args) {
        Animal4 dogg = new Dogg();
        Animal4 catt = new Catt();
        Animal4 sheepp = new Sheepp();

        playAnimalSound(dogg);
        playAnimalSound(catt);
        playAnimalSound(sheepp);
    }

    public static void playAnimalSound(Animal4 animal4) {
        animal4.sound();
    }
}
