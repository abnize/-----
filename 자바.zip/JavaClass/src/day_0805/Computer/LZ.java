package day_0805.Computer;

public class LZ extends Computer {
    @Override
    void powerOn() {
        super.powerOn();
        System.out.println("사랑해요 LZ");
    }
}
