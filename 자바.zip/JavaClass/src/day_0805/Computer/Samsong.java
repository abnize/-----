package day_0805.Computer;

public class Samsong extends Computer{
    @Override
    void powerOn() {
        super.powerOn();
        System.out.println("아이 러브 삼성");
    }
}
