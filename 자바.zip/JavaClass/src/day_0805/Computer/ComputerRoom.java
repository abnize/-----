package day_0805.Computer;

public class ComputerRoom {
//    Samsong computer1;
//    Samsong Computer2;
//
//    LZ computer1;
//    LZ computer2;

    Computer computer1;
    Computer computer2;

    void allPowerOn() {
        computer1.powerOn();
        computer2.powerOn();
    }

    void allPowerOff() {
        computer1.powerOff();   // 부모클래스(computer)에 있는 메서드
        computer2.powerOff();
    }
}
