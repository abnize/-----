package day_0805.Computer;

public class Main {
    public static void main(String[] args) {
        ComputerRoom cr = new ComputerRoom();

//        cr.computer1 = new Samsong();
//        cr.computer2 = new Samsong();

        // LZ computer1 = new(LZ); === 바꾸기 전
        cr.computer1 = new Samsong();
        cr.computer2 = new LZ();

        // Computer computer1 = new(LZ); === 바꾼 후
        cr.allPowerOn();
        cr.allPowerOff();
    }
}
