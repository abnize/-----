package day_0805.Computer;

public class Computer {
    void powerOn() {
        System.out.println("삐 - 컴퓨터가 켜졌습니다.");
    }

    void powerOff() {
        System.out.println("컴퓨터가 종료됩니다.");
    }
}
