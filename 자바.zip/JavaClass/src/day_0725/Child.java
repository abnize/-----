package day_0725;

import day_0724.BlackBox;

public class Child {

    String name;
    private int age;
    static String bark;
    String nap;
    String spinach;
    String friend;

    public Child(String name, int age, String friend) {  // 생성자 (기본 세팅)
        this.name = name;
        this.age = age;
        this.friend = friend;
    }

    public Child() { //기본

    }

    public void introduce() {
        System.out.println("안녕- 하세-요.");
        System.out.println("제 이름은 "+this.name+" 이고, 나이는 "+this.age+"살 입-니다아.");
        if (friend != null) {
            System.out.println("제-일 친한 친구는 " + this.friend + " 입니다아!");
    }
}
    public int getAge() {
        return age;
    }

    void talk() {
        System.out.println("반갑습ㄴ디ㅏ.");
    }

    void introDream(String dream) {
        System.out.println("꿈은 " + dream + " 입니다.");
    }

    public void setAge(int age) {
        if (age >= 1) {
            this.age = age;
        } else {
            System.out.println("나이는 1살부터 입력 가능!!");
        }
        }

        int Tastes(int favorite) {
            System.out.println("저는 매일 " + favorite + " 시간을 갖습니다아 ");
            System.out.println("졸려요");
            return favorite;
        }

        void Taste(String favorite, String hate) { //메서드 오버라이딩
            System.out.println("제가 제일 좋아하는 건- " + favorite + "이고,");
            System.out.println("싫어하는 거언 " +hate+ " 입니다아. " );

        }
        }
