package day_0725;

import day_0724.Cat;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Child child1 = new Child("김어린이", 4, "루루, 나나, 미미, 사사");

        Scanner sc = new Scanner(System.in);

        child1.introduce();

        System.out.println();

//      child1.setName("김어린이");
        child1.setAge(4);

        Child kim = child1;
        kim.introDream("경찰차");
        kim.talk();

        System.out.println();

        kim.Taste("낮잠", "시금치");

    }
}
