package day_0807;

public class _07_LocalClass2 {
    void myMethod() {
        // 지역 클래스 정의
        class LocalClass {
            void display() {
                System.out.println("지역 클래스에서 실행됨");
            }
        }

        // 지역 클래스의 인스턴스 생성 및 메서드 호출
        LocalClass local = new LocalClass();
        local.display();
    }

    public static void main(String[] args) {
        _07_LocalClass2 outer = new _07_LocalClass2();
        outer.myMethod(); // 메서드 호출
    }
}
