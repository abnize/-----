package day_0807;

interface Greeting {
    void sayHello();
}

public class AnonymousClassEX {
    public static void main(String[] args) {

        Greeting greeting = () -> System.out.println("익명클래스입니다.");

        greeting.sayHello();
        //익명 클래스
        //실행
    }
}
