package day_0807;

interface buttonClickListener {
    public void click();
}

public class _06_AnonymousClass2 {

    public class Button {
        private buttonClickListener listener;

        public void setButtonListener(buttonClickListener listener) {
            this.listener = listener;
        }

        public void click() {
            if (listener != null) {
                this.listener.click();
            }
        }
    }

    public static void main(String[] args) {
        _06_AnonymousClass2 exam = new _06_AnonymousClass2();
        _06_AnonymousClass2.Button button = exam.new Button();

        buttonClickListener listener = new buttonClickListener() {
            @Override
            public void click() {
                System.out.println("버튼을 눌렀습니다.");
            }
        };
        button.setButtonListener(listener);
        button.click();
    }
}