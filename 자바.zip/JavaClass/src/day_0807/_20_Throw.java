package day_0807;

import java.util.Scanner;

public class _20_Throw {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);

        try {
            System.out.println("신분증 좀 보여주세요.");
            int age = scan.nextInt();

            if (age < 20) {
                throw new InputErrorException("19세 미만에게는 담배를 판매하지 않습니다.");
            } else if (age > 19) {
                System.out.println("어떤 걸로 드릴까요?");
            }
        } catch (InputErrorException e) {
                    System.out.println(e.getMessage());
                } finally {
                    if (scan != null) {
                        scan.close();
                    }
                }
            }
        }
