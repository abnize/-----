package day_0807;

public class _10_ArrayIndexOutOfBoundsException {
    public static void main(String[] args) {
        int[] arr = {1, 6, 7, 9, 10};
        System.out.println(arr[5]);
    }
}
