package day_0807;

public class _08_NullPointException {
    public static void main(String[] args) {
        String[] strArray = null;

        System.out.println(strArray[0]);
    }
}
