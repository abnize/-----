package day_0808;

import java.util.ArrayList;
import java.util.List;

public class _Quiz_ArrayList {
    public static void main(String[] args) {

        List<Student> list = new ArrayList<>();
        list.add(new Student("가나나", "파이썬"));
        list.add(new Student("박디도", "자바"));
        list.add(new Student("이삭", "C"));
        list.add(new Student("황금별", "자바"));
        list.add(new Student("예만해", "파이썬"));
        list.add(new Student("엄청나", "자바"));
        list.add(new Student("김보나벤투라", "C"));

        System.out.println("자바 자격증을 보유한 학생");
        System.out.println("----------------");
        for(Student s : list) {
            if(s.certification.equals("자바")) {
                System.out.println(s.name);
            }
        }
    }
}

class Student {
    public String name;
    public String certification;

    public Student(String name, String certification) {
        this.name = name;
        this.certification = certification;
    }
}

// Student 클래스
