package day_0808.Lambda;

public interface Calculator {
    int compute(int a, int b);
}
