package day_0808.Lambda;

public interface MyRunnable {
    void run();
}
