package day_0808.Lambda;

public interface MyPrinter {
    void print(String message);
}
