package day_0808.Lambda;

public interface StringLength {
    int getLength(String s);
}
