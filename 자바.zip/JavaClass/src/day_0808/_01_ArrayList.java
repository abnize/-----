package day_0808;
import java.util.ArrayList;
import java.util.List;

public class _01_ArrayList {
    public static void main(String[] args) {

        List<String> list = new ArrayList<>();

        list.add("딸기");
        list.add("바나나");
        list.add("망고");

        System.out.println("리스트 내용1: " + list);

        list.add(2, "수박");

        System.out.println("리스트 내용2 : " + list);

        list.set(1, "복숭아");
        list.set(0, "파인애플");

        list.remove(1);
        list.remove("수박");

        System.out.println("리스트 내용3 : " + list);

    }
}
