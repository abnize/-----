package day_0808;

public class _00_Generics {
    public static void main(String[] args) {

        Integer[] iArray = {1,2,3,4,5};
        Double[] dArray = {1.0, 2.0, 3.0, 4.0, 5.0};
        String[] sArray = {"A", "B", "C", "D", "E"};

        System.out.println("============");

        printStringArray(sArray);

    printAnyArray(iArray);
    printAnyArray(dArray);
    printAnyArray(sArray);

}

    private static <T> void printAnyArray(T[] array) {
        for (T t : array) {
            System.out.print(t +" ");
        }
        System.out.println();
    }

    private static void printStringArray(String[] sss) {
        for (String  s : sss) {
            System.out.print(s +" ");
        }
        System.out.println();
    }

    private static void printDoubleArray(Double[] ddd) {
        for (Double  d : ddd) {
            System.out.print(d +" ");
        }
        System.out.println();
    }
    private static void printIntArray(String[] iii) {
        for (String  i : iii) {
            System.out.print(i +" ");
        }
        System.out.println();
    }
}
