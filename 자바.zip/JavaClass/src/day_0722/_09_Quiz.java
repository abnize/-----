package day_0722;

public class _09_Quiz {
    public static void main(String[] args) {
        String Jumin = "901230 - 2015554";
        String Birthday = Jumin.substring(0, 6);
        System.out.println(Birthday);


        // substring 생일 뽑기
        // substring 과 삼향연산과 ( == / equals ) 이용해서 M / F 인지 뽑아오기
        // 그래서 "생일은 ~~ 이고 성별은 ~ 입니다." 라고 출력하기



        char Gender = Jumin.replace(" ","").charAt(7);
        String gender = (Gender == '1' || Gender == '3') ? "남자":
                        (Gender == '2' || Gender == '4') ? "여자" : "알 수 없음";

        System.out.println("생일은" + Birthday + " 이고 성별은 " + gender + "입니다.");
    }
}

