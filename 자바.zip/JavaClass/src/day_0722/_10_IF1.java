package day_0722;

import java.util.Scanner;

public class _10_IF1 {
    public static void main(String[] args) {
        int result = 0;
        if (3 > 4) {
            result = 3;
        }
        System.out.println(result);

        Scanner sc = new Scanner(System.in);
        System.out.println("나이를 입력 하세요 => ");

        int age = sc.nextInt();
        if (age >= 19) {
            System.out.println("성인입니다.");
        }
        if (age < 20) {
            System.out.println("미성년자입니다.");
        }
        System.out.println("종료 코드 0(으)로 완료된 프로세스");
    }
}
