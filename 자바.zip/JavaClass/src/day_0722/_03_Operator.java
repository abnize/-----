package day_0722;

public class _03_Operator {
    public static void main(String[] args) {

        //이중 삼항 연산자를 이용해 크다 작다 같아 판별하기
        // 1. a와 b 중 누가 큰지 a가 크다 or b가 크다 둘 중 하나 받아오기

        int a = 5;
        int b = 7;

        String result1 = (a > b)? "a가 b보다 큽니다." : "b가 a보다 큽니다.";
        System.out.println("결과는 " + result1);

        // 2. a가 크다 or b가 크다 or 둘이 같다 중 하나 받아오기

        int c = 10;
        int d = 10;

        String result2 = (c > d)? "a가 b보다 큽니다." : (c < d)? "b가 a보다 큽니다." : "둘은 같습니다.";
        System.out.println("결과는 " +result2);

    }
}
