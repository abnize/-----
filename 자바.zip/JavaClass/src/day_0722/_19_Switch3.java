package day_0722;

import java.util.Scanner;

public class _19_Switch3 {
    public static void main(String[] args) {
        // 1,2,3, 그 외등급이 있다
        // 그외등급은 40만원
        // 기본 3등급 50만원 2등급 +10만원 => 60만원
        // 1등급은 거기에 +10, 총 70만원 장학금!
        Scanner sc = new Scanner(System.in);
        System.out.println("등급을 입력 하세요 => ");
        int grade = sc.nextInt();
        int money = 400000;

        switch (grade) {
            case 1:
                System.out.printf("1등급은 70만원");
                break;
            case 2:
                System.out.printf("2등급은 60만원");
                break;
            case 3:
                System.out.printf("3등급은 50만원");
                break;
            default:
                System.out.println("40만원입니다.");
                break;
        }
    }
}
