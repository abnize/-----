package day_0722;

public class _01_Variable {
    public static void main(String[] args) {
        String name = "김이름";
        int age = 27;
        double height = 183.5;
        char gender = 'M';
        short seat_number = 1;

        System.out.println("자기소개를 해보겠습니다.");
        System.out.println("제 이름은 " + name + "이고 나이는 " + age + "살 이고 키는 " + height + "입니다.");
        System.out.println("저의 성별은 " + gender + "이고 책상 번호는 "+ seat_number + "입니다.");

        System.out.println("저는 굿맨일까요?");
        boolean isGoodman = true;
        System.out.println(isGoodman);  // true


    }


}
