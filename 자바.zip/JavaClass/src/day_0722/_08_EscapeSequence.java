package day_0722;

public class _08_EscapeSequence {
    public static void main(String[] args) {

        // 특수문자, 이스케이프 문자
        // \n   \t  \\  \"  \'

        System.out.println("날씨가");
        System.out.println("정말");
        System.out.println("좋아요");

        System.out.println("날씨가\n정말\n좋아요");

        // 빽다방 2000원
        // 스타벅스 5000원
        System.out.println("빽다방 2000원");
        System.out.printf("스타벅스 5000원");

        System.out.println("빽다방\t2000원");
        System.out.printf("스타벅스\t5000원");   // 띄어쓰기 맞춤

        System.out.println("C:\\Program Files\\Java");  // 역슬래시 자체 표현

        // 강아지가 "멍멍" 짖는다.
        System.out.println("강아지가 \"멍멍\" 짖는다");
        System.out.println("팽순이 \'왈왈\' 짖어오기");
        System.out.println("송이가 \'짹짹\' 울어요");
    }
}
