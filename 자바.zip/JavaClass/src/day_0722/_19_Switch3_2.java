package day_0722;

import java.util.Scanner;

public class _19_Switch3_2 {
    public static void main(String[] args) {
        // 1,2,3, 그 외등급이 있다
        // 그외등급은 40만원
        // 기본 3등급 50만원 2등급 +10만원 => 60만원
        // 1등급은 거기에 +10, 총 70만원 장학금!

        int grade = 1;
        int money = 400000;

        switch (grade) {
            case 1:
                money += 100000;
            case 2:
                money += 100000;
            case 3:
                money += 100000;
            default:
                break;
        }
        System.out.println("장학금은 " +money);
    }
}
