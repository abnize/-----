package day_0722;

public class _05_String1 {
    public static void main(String[] args) {

        String s = "I like Java and Python and C.";
        System.out.println(s);

        // Scanner sc = new Scanner(System.in);
        // sc.next();
        // sc.nextLine(); . . .

        // 문자 열의 길이
        System.out.println(s.length());

        // 대소문자 변환
        System.out.println(s.toUpperCase());
        System.out.println(s.toLowerCase());

        // 포함 관계
        System.out.println(s.contains("Java")); // true
        System.out.println(s.contains("C#")); // false
        System.out.println(s.indexOf("Java")); // 7
        System.out.println(s.indexOf("and")); // 처음 만나는 위치 정보
        System.out.println(s.lastIndexOf("and")); //마지막 만나는 정보
        System.out.println(s.startsWith("I like")); // true
    }
}
