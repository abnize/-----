package day_0722;

public class _16_Else_If2 {
    public static void main(String[] args) {
        boolean jaeyook = false;
        boolean donggass = false;

        if(jaeyook) {
            System.out.println("난 제육을 먹겠어");
        } else if (donggass) {
            System.out.println("돈가스 먹지 뭐");
        } else {
            System.out.println("김치찌개로 괜찮아");
        }
        System.out.println("금방 갈게 전화 끊어");
    }
}
