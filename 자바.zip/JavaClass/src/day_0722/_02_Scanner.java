package day_0722;

import java.util.Scanner;

public class _02_Scanner {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String name;
        int age;
        double height;

        System.out.println("당신의 이름은 무엇입니까 => ");
        name = sc.nextLine();

        System.out.println("당신의 나이는 몇 살입니까 => ");
        age = sc.nextInt();
        sc.nextLine();

        System.out.println("당신의 키는 몇 입니까 => ");
        height = sc.nextDouble();


        System.out.printf("당신의 이름은 %s이고 나이는 %d살 키는 %.1f cm 입니다." , name, age, height);
    }
}
