package day_0722;

public class _13_If_Else_max {
    public static void main(String[] args) {
        int a = 4;
        int b = 10;
        int max = 0;

    // 여기에 if elses  문 적어
        if (a > b) {
            max = a;
        } else {
            max = b;
        }

    System.out.println(a+ "와" + b + " 중에 큰 수는 " + max + "입니다.");
}
}