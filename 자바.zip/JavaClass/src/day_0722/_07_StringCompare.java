package day_0722;

public class _07_StringCompare {
    public static void main(String[] args) {
        // 문자열 비교
        String s1 = "Java";
        String s2 = "Python";

        System.out.println(s1.equals(s2)); // 내용이 같으냐? true / false
        System.out.println(s1.equals("Java")); // 내용이 같으다.
        System.out.println(s2.equals("python")); // 대소문자 구분한다!
        System.out.println(s2.equalsIgnoreCase("python")); // 대소문자 무시 비교

        // 비교 심화 버전
        s1 = "1234";
        s2 = "1234";
        System.out.println(s1.equals(s2)); // 내용기 같다! true
        System.out.println(s1 == s2); // true

        // equals 와 ==
        s1 = new String("1234");
        s2 = new String("1234");
        System.out.println(s1.equals(s2)); // true
        System.out.println(s1 == s2); // false

        // equals => 내용 비교
        // ==     => 주소 비교




    }
}
