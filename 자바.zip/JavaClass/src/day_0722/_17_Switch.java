package day_0722;

import java.util.Scanner;

public class _17_Switch {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("숫자를 입력 하세요 => ");
        int num = sc.nextInt();

        switch (num) {
            case 1 :
                System.out.println("숫자는 1입니다.");
                break;
            case 2 :
                System.out.println("숫자는 2입니다.");
                break;
            case 3 :
                System.out.println("숫자는 3입니다.");
                break;
            case 4 :
                System.out.println("숫자는 4입니다.");
                break;
            case 5 :
                System.out.println("숫자는 5입니다.");
                break;
            default:
                System.out.println("잘못입력했습니다. 다시 입력해주세요.");
        }







        //1부터 5까지 케이스 만들어서 숫자 몇인지 출력해주고 잘못 입력했음 오류 메세지 출력
    }
}
