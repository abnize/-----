package day_0722;

public class _06_String2 {
    public static void main(String[] args) {
        String s =  "I like java and Python and C.";

        // 문자열 반환
        System.out.println(s.replace("and", ",")); // and를 콤마로 변환
        System.out.println(s.substring(7)); // 인덱스 7번 부터 끝까지 뽑아냄.
        System.out.println(s.substring(s.indexOf("Java"))); // "Java" 의 인덱스 번호를 뽑아와서 실행.
        System.out.println(s.substring(s.indexOf("Java"), s.indexOf("."))); // 시작부터 끝 위치 전까지!

        // 변수에 넣어서 사용
        String java_cut = s.substring(7);
        System.out.println(java_cut);

        // 공백 제거
        s = "       I Love you.     ";
        System.out.println(s);
        System.out.println(s.trim()); // 앞뒤 공백 제거

        // 문자열 결함
        String s1 = "I love";
        String s2 = "you";
        System.out.println(s1 + " " + s2);
        System.out.println(s1.concat(s2));
        System.out.println(s1.concat(" ").concat(s2));
    }
}
