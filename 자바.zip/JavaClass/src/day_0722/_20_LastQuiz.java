package day_0722;
import java.util.Scanner;
public class _20_LastQuiz {
    public static void main(String[] args) {

        // 주차 시간 당 4000원
        // 하루 최대 30000원
        // 경차 or 장애인 = 50%
        // 주차시간, 경차인지, 장애인인지 scanner로 입력받고 최종 주차요금 출력하시오
        // isSmallcar 경차
        // isDisabledPerson 장애인
        // fee 요금

        Scanner sc = new Scanner(System.in);

        String isDisabledPerson;
        String isSmallcar;
        int fee = 4000;
        double parktime;

        System.out.println("주차시간이 몇 시간 입니까? => ");
        parktime = sc.nextDouble();
        sc.nextLine();
        System.out.println("장애인입니까? (y/n) => ");
        isDisabledPerson = sc.nextLine();
        System.out.println("경차입니까? (y/n) => ");
        isSmallcar = sc.nextLine();

        int total = (int) (parktime * fee); //total = 총 금액
        if (total > 30000){
            total = 30000;
        }

        if (isDisabledPerson.equals("y") || isSmallcar.equals("y") ) {
            total /= 2;
        }

        System.out.println("총 요금은 "+total+ "입니다.");

    }
}
