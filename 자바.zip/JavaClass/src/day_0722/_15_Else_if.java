package day_0722;

import java.util.Scanner;

public class _15_Else_if {
    public static void main(String[] args) {
        int favorite = 18;

        if(favorite < 10) {
            System.out.println("좋아하는 숫자가 10보다 작군요?");
        } else if (favorite > 10) {
            System.out.println("좋아하는 숫자가 10보다 크군요?");
        } else {
            System.out.println("좋아하는 숫자가 10이군요?");
        }

        Scanner sc = new Scanner(System.in);
        System.out.println("나이를 입력하세요 =>");
        int age = sc.nextInt();
        // 19세 초과 -> '성인입니다.'
        // 13세 초과 -> '청소연입니다.'
        // 6세 초과 -> '어린이입니다.'
        // 나머지는 -> ' 유아입니다.'

        if (age > 19) {
            System.out.println("성인입니다.");
        } else if(age>13) {
            System.out.println("청소년입니다.");
        }else if(age>6) {
            System.out.println("어린이입니다.");
        } else {
            System.out.printf("유아입니다.");
        }
    }
}
