package day_0722;

public class _18_Switch2 {
    public static void main(String[] args) {

        int ranking = 1;
        switch (ranking) {
            case 1 :
                System.out.printf("장학금은 100만원");
                break;
            case 2:
            case3:
            System.out.printf("장학금은 50만원");
                break;
            default:
                System.out.println("장학금은 없습니다.");
        }

        // if elseif else 로 구현 하시오.

        if (ranking == 1) {
            System.out.println("장학금은 100만원");
        } else if (ranking == 2 || ranking == 3) {
            System.out.println("장학금은 50만원");
        } else {
            System.out.println("장학금은 없습니다.");
        }
    }
}
