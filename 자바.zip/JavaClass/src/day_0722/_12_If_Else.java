package day_0722;

public class _12_If_Else {
    public static void main(String[] args) {
        int num = 5;

        if (num > 4) {
            System.out.println(num + "는 4보다 큽니다.");
        } else {
            System.out.println(num + "는 4보다 작거나 같습니다.");
        }

        int a = 3;
        int b =  10;

        if(a>b) {
            System.out.println();
        } else {
            System.out.println("a가 b보다 작습니다.");
        }

    }
}
