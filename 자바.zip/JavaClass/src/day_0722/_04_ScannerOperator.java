package day_0722;

public class _04_ScannerOperator {
    public static void main(String[] args) {

    }
}
