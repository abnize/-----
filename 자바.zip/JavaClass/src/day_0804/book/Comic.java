package day_0804.book;

public class Comic extends Book {
    boolean isColor;

    Comic(String title, String author, boolean isColor) {
        super(title, author);
        this.isColor = isColor;
    }

    // 부모 메서드에서 final 이어서 오버라이딩 불가

//    @Override
//    final void info_title() {
//        System.out.println("이 만화책의 제목은" + title + "입니다.");
//    }

    @Override //어노테이션
    void info_author() {
        System.out.println("이 만화책의 저자는 " + author + "입니다.");
    }

    void info_color() {
        System.out.println("이 만화책의 저자는" );
    }
}
