package day_0804.book;

public class Main {
    public static void main(String[] args) {
        Comic comicBook = new Comic("해리포터", "롤랑", true);

        comicBook.info_author();  // 오버라이딩된 메서드 호출
        comicBook.info_title();   // 직접 정의한 메서드 호출
    }
}
