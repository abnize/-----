package day_0804;

public class Computer_main {
    public static void main(String[] args) {
        Samsong s = new Samsong();
        s.powerOn();
        s.powerOff();

        Computer c =  new Computer();
        c.powerOn();
        c.powerOff();
    }
}
