package day_0804;


public class Samsong extends Computer{
    @Override
    void powerOn() {

    }

    public void powerOff() {
    }

}
