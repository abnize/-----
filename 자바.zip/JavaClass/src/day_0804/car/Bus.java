package day_0804.car;

        public class Bus extends Car {
            int peopleNum;

            Bus(int peopleNum) {
                this.peopleNum = peopleNum;
            }

            void takePerson() {
                System.out.println("승객이 버스에 탔습니다.");
                peopleNum++; // 인원만 증가시키고 출력은 안 함
            }

        @Override
        public String toString() {
            return "지금까지 탑승한 승객은 " + peopleNum + "명입니다.";
    }
}


