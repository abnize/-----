package day_0804.car;

public class Car {
    void ride() {
        System.out.println("달립니다.");
    }
}
