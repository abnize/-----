package day_0804.car;

public class Main {
    public static void main(String[] args) {
        SchoolBus sb = new SchoolBus(30);
        sb.takePerson();
        sb.ride();
        System.out.println(sb);
    }
}
