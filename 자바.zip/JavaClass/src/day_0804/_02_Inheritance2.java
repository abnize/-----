package day_0804;

import day_0804.Camera.Camera;
import day_0804.Camera.FactoryCam;
import day_0804.Camera.SpeedCam;

public class _02_Inheritance2 {
    public static void main(String[] args) {
        Camera camera = new Camera();
        FactoryCam factoryCam = new FactoryCam();
        SpeedCam speedCam = new SpeedCam();

        System.out.println(camera.name);
        System.out.println(factoryCam.name);
        System.out.println(speedCam.name);

        camera.takePicture();
        factoryCam.recordVideo();
        speedCam.takePicture();

        camera.showMainFeature();
        factoryCam.showMainFeature();
        speedCam.showMainFeature();

        // ================= 8/5  다형성 ===============

        System.out.println("===================다형성 이용 ++++++++++++++++++");

        Camera[] cameras = new Camera[3];
        cameras[0] = new Camera();
        cameras[1] = new FactoryCam();
        cameras[2] = new SpeedCam();

        for (Camera cam : cameras) {
            cam.showMainFeature();
        }
    }
}
