package day_0804;

public class Person_main {
    public static void main(String[] args) {
        Customer c1 = new Customer("박자바", 25, 11111);
        c1.enter();

        Customer c2 = new Customer("송코딩", 20, 22222);
        c2.enter();
    }
}
