package day_0804;

public class Comic extends Book {
}
