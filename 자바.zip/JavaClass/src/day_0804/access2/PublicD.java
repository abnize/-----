package day_0804.access2;

import day_0804.access1.PublicA;

public class PublicD {
    public static void main(String[] args) {
        PublicA a = new PublicA(10);
    }
}
