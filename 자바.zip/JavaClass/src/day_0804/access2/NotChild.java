package day_0804.access2;

import day_0804.access1.Parent;

public class NotChild {
    void accessTest() {
        Parent p2 = new Parent();
        p2.accessProtected();
    }
}
