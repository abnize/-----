package day_0804;

public class Book {
    String title;

}
