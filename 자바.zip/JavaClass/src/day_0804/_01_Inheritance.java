package day_0804;

public class _01_Inheritance {
    public static void main(String[] args) {
        Comic comicBook = new Comic();
        comicBook.title = "포켓몬";

    }
}
