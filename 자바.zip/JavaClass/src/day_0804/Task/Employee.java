package day_0804.Task;

public class Employee {

    private String name;
    protected String position;

    public Employee(String name) {
        this.name = name;
        this.position = "직원";  // 기본 직책
    }

    public String getName() {
        return this.name;
    }

    public void work() {
        System.out.println(name + "은(는) 업무를 수행합니다.");
    }

    public void showInfo() {
        System.out.println(name + " / 직책: " + position);
    }
        public String getname() {
            return name;

    }
}