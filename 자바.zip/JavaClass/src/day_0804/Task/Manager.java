package day_0804.Task;

public class Manager extends Employee{

    public Manager(String name) {
        super(name);
        this.position = "관리자";  // 직책 변경
    }

    @Override
    public void work() {
        System.out.println(getName() + "은(는) 회의를 주재합니다.");
    }

    @Override
    public void showInfo() {
        System.out.println(getName() + " / 직책: " + position);
        System.out.println("추가 역할: 팀 관리");
    }
}
