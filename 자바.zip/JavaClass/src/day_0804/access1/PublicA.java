package day_0804.access1;

public class PublicA {
    public int a;


    public PublicA(int a) {
        this.a = a;
    }

    public void printA() {
        System.out.println("publicA 클래스의 printA() 메서드입니다.");
    }

    DefaultC dc = new DefaultC();
    void method() {
        dc.variable = 20;
    }
}