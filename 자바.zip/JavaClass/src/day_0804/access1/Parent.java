package day_0804.access1;

public class Parent {
    public void accessProtected() {
        System.out.println("protected 멤버에 ");
    }
}
