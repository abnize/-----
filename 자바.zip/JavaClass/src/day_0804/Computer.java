package day_0804;

public class Computer {
    void powerOn() {
        System.out.println("삑 = 컴퓨터가 커졌습니다.");
        System.out.println("컴퓨터가 종료됩니다.");
    }

    public void powerOff() {

    }
}
