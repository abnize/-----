package day_0804.Camera;

public class SlowActionCam extends ActionCam {
    public SlowActionCam() {
        this.name = "슬로우 액션 카메라";
    }

    @Override
    public void makeVideo() {
        System.out.println("");
    }

    @Override
    public void recordVideo() {
        // lens는 final이라 값 변경 불가
        System.out.println(this.name + " : " + this.lens + "로 슬로우모션 비디오를 녹화합니다.");
    }
}
